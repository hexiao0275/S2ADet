This code is ONLY released for academic use. Please do not further distribute the code (including the download link), or put any of the code on the public website. 

Please kindly cite our paper if you use our code in your research. Thanks and hope you will benefit from our code. 

Q. Wang, F. Zhang, and X. Li, "Optimal Clustering Framework for Hyperspectral Band Selection," IEEE Transactions on Geoscience and Remote Sensing (T-GRS), vol. 56, no. 10, pp. 5910-5922, 2018.

See Demo.m for more details.
